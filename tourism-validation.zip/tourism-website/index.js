document.getElementsByClassName('index')[0].addEventListener('onmouseover',function(e){
console.log('its working');

})